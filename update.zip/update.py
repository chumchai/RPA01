import subprocess
import zipfile
import requests

# ตั้งค่า URL และชื่อไฟล์
GITHUB_URL = "https://github.com/yourusername/yourrepository/releases/latest/download/update.zip"
VERSION_FILE_PATH = "version.txt"  # ไฟล์ที่เก็บเวอร์ชัน

# ฟังก์ชันเพื่อตรวจสอบเวอร์ชัน
def check_version():
    response = requests.get(GITHUB_URL.replace("update.zip", "version.txt"))
    return response.text.strip()

# ฟังก์ชันดาวน์โหลด zip
def download_update():
    response = requests.get(GITHUB_URL)
    with open("update.zip", "wb") as f:
        f.write(response.content)

# ฟังก์ชันอัปเดตไฟล์
def update_files():
    with zipfile.ZipFile("update.zip", 'r') as zip_ref:
        zip_ref.extractall(".")

def main():
    # ตรวจสอบเวอร์ชันใหม่
    latest_version = check_version()
    
    # ดาวน์โหลด update.zip
    download_update()

    # อัปเดตไฟล์
    update_files()
    print("อัปเดตเสร็จสิ้น!")

    # เปิดโปรแกรมหลักหลังอัปเดต
    subprocess.Popen(["python", "main.py"])

if __name__ == "__main__":
    main()
